import { Container, Navbar, NavbarBrand } from "react-bootstrap";
import 'bootstrap/dist/css/bootstrap.min.css';



const TopBar = (props) => {
    return (
        <Navbar expand="lg" style={{
        backgroundColor: "#ffffff",
        borderRadius: "12px",
        overflow: "hidden",
        boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
        border: "1px solid #e0d0c1",
        display: "flex",
        flexDirection: "column",
      }}>
            <Container fluid>
                {props.title}
            </Container>
        </Navbar>
    );
};

export default TopBar;
