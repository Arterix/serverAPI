import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Button from 'react-bootstrap/Button';
import ExploreContainer from '../components/ExploreContainer';
// import './Tab1.css';
import KopiCard from '../components/KopiCard';
import TopBar from '../components/TopBar';



const Tab1 = () => {
  return (
    // console.log("hello")
    <Container fluid>
      <Row>
        <TopBar title="Home"></TopBar>
        {/* <Button variant="primary">Primary</Button> */}
      </Row>
      <Row className="justify-content-md-center">
        <Col md="auto">
          <KopiCard name="Espresso" deskripsi="kopi item"></KopiCard>
        </Col>  
        <Col md="auto">
          <KopiCard name="Espresso" deskripsi="kopi item"></KopiCard>
        </Col>
        <Col md="auto">
          <KopiCard name="Espresso" deskripsi="kopi item"></KopiCard>
        </Col>
      </Row>
    </Container>
  );
};

export default Tab1;
